const mongoose = require("mongoose");
const initData = require("./data.js");
const listings = require("../models/listing.js");

main().then(() => {
    console.log("coonect to db by index.js");
}).catch((err) => {
    console.log(err);
});

async function main() {
    await mongoose.connect("mongodb://127.0.0.1:27017/WonderLust");
}

const initDB = async () => {
    await listings.deleteMany({});
    await listings.insertMany(initData.data);
}

initDB();