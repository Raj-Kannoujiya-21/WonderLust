const express = require("express");
const app = express();
const mongoose = require("mongoose");
const listing = require("./models/listing.js");
const path = require("path");
const methodOverride = require("method-override");
const ejsMate = require("ejs-mate");

main().then((res) => {
    console.log("connect to db...");
});

async function main(){
    await mongoose.connect("mongodb://127.0.0.1:27017/WonderLust");
}

app.set("view engine" , "ejs");
app.set("views" , path.join(__dirname , "views"));
app.use(express.urlencoded ( { extended : true}));
app.use(methodOverride("_method"));
app.engine("ejs" , ejsMate);
app.use(express.static(path.join(__dirname , "./public")));

// app.get("/testList" , (req , res) => {
//     const sampleListings = new listing({
//         title : "Summer Seattle stock",
//         description : "Seattle, Washington",
//         price : 1500,
//         location : "Washington",
//         country : "USA",
//     });

//     sampleListings.save().then((res) => {
//         console.log("data is saved");
//     }).catch((err) => {
//         console.log(err);
//     });
// })

// Index Route

app.get("/listings" , async(req , res) => {
   const allListings = await listing.find({});
    res.render("./listings/index.ejs" , {allListings});
});

// Add New Route

app.get("/listings/new" , (req, res) => {
    res.render("./listings/new.ejs");
});

//create new route

app.post("/listings" , async(req , res) => {
   const newListing = new listing (req.body.listings);
   await newListing.save();

   res.redirect("/listings");

});

//Show Route

app.get("/listings/:id" , async(req , res) => {
    let {id} = req.params;
    const listings = await listing.findById(id);
    res.render("./listings/show.ejs" , {listings});
});

//Edit Route

app.get("/listings/:id/edit" , async(req ,res) => {
    let {id} = req.params;
    const listings = await listing.findById(id);
 
    res.render("./listings/edit.ejs" , {listings});
});

//Update Route

app.put("/listings/:id" , async(req , res) => {
    let {id} = req.params;
    await listing.findByIdAndUpdate(id,{...req.body.listings});
    res.redirect(`/listings/${id}`);
});

//Delete data

app.delete("/listings/:id" ,async (req ,res) => {
    let {id} = req.params;
    let deleteData =await listing.findByIdAndDelete(id);
    console.log(deleteData);
    res.redirect("/listings");
});




app.get("/" , (req , res) => {
    res.send("root is working..")
});

app.listen(8080 , () => {
    console.log("Server listening on the port");
});